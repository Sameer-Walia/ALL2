import './App.css';
import Login from './Login';
import Register from './Register';
import { useEffect, useState } from 'react';
import { getAuth , onAuthStateChanged } from 'firebase/auth';
import { initializeApp } from 'firebase/app';
import HomeHeader from './HomeHeader';
import { BrowserRouter as Router, Route, Switch, Routes } from 'react-router-dom';

function App() {

  const firebaseConfig = {
    apiKey:"AIzaSyADChs8ohaekwJvng015hNC4TSWrP1p-qo",
    authDomain: "facebook-f3bd1.firebaseapp.com",
    projectId: "facebook-f3bd1",
    storageBucket: "facebook-f3bd1.appspot.com",
    messagingSenderId: "87140365447",
    appId: "1:87140365447:web:d43d81149e23df88dfb422",
    measurementId: "G-FHXFR6GW8X"
};

  const app = initializeApp(firebaseConfig);
  const auth = getAuth(app);

  const[user , setuser] = useState();


  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (authUser) => {
      if (authUser) 
      {
        setuser(authUser);
      } 
      else 
      {
        setuser(null);
      }
    });

    return () => unsubscribe();
  }, []);

  

  return (
    <div className="app">
        <Routes>
            <Route path="/login" element={<Login/>}></Route>
            <Route path="/register" element={<Register/>}></Route>
            <Route path='/' element={<HomeHeader user={user} selected/>}></Route>
        </Routes>
    </div>
  );
}
export default App;
