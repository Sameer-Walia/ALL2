import React, { useState } from 'react'
import './Login.css';
import { Link , useNavigate} from 'react-router-dom';
import {auth } from './firebase';
import { signInWithEmailAndPassword } from 'firebase/auth';

 function Login() 
 {

  const navigate = useNavigate();
  const [email , setemail]= useState('')
  const[password , setpassword] = useState('')

  function onlogin(e)
  {
    e.preventDefault();
    signInWithEmailAndPassword(auth ,email, password)
    .then((auth)=>{
      navigate("/")
    })
    .catch((error)=>{
      if(e.message==="The password is invalid or the user doesnot have a password")
      {
        alert("Please check your credentials again")
      }
      else if(e.message==="there is no user record corresponding to this identifier, the user may have been deleted")
      {
        alert("Please check your credentials again")
      } 
      else
      {
        alert(e.message)
      }

    })
  }

  return (
    <div className="login">
      <img src='images/pngimg.com - facebook_logos_PNG19749.png' className='login_logo'></img>
      <div className='login_container'>
          <h3>Log In to Facebook</h3>
          <form>
              <center>
                <input type='email'placeholder='Email Address'onChange={(e)=>setemail(e.target.value)}/>
              </center>
              <center>
                <input type='Password'placeholder='Password'onChange={(e)=>setpassword(e.target.value)}/>
              </center>
              <center>
                <button type='submit' onClick={onlogin} className='login_login'>Log In</button>
              </center> 
              <center>
                <div className='sideinfo'>
                    <h5>Forget Password ?</h5>
                    <h5 className='dot'>-</h5>
                    <Link to="/register" style={{textDecoration: 'none'}}>
                        <h5 className='rtd'>Sign Up for Facebook</h5>
                    </Link>
                </div>
              </center>
          </form>
      </div>
    </div>
    
  )
}
export default Login;