import React, { useState } from 'react'
import "./Register.css"
import  {Link, useNavigate} from 'react-router-dom';
import { createUserWithEmailAndPassword, getAuth, updateProfile } from 'firebase/auth';
import { getFirestore , doc, setDoc } from "firebase/firestore";



function Register() {

  const db = getFirestore();
  const auth = getAuth();
  const[firstname , setfirstname] = useState();
  const[lastname , setlastname] = useState();
  const[email , setemail] = useState();
  const[password , setpassword] = useState();
  const[birthday , setbirthday] = useState([]);
  const[gender , setgender] = useState();
  const navigate = useNavigate();

  // function onregister(e)
  // {
  //     e.preventDefault();
  //     createUserWithEmailAndPassword(auth ,email , password)
  //     .then((userCredential)=>{
  //       const user = userCredential.user;
  //       if(user)
  //       {
  //         return updateProfile( user , {
  //           displayName:firstname+" "+lastname,
  //           photoURL:"images/faceuser.png"
  //         })
  //         .then(()=>{
  //           return db.collection('users').doc(user.uid).set({
  //             uid:user.uid,
  //             displayName:user.displayName,
  //             email:user.email,
  //             photoURL:"images/faceuser.png",
  //             birthday,
  //             gender,
  //             bio:""
  //           })
  //           .then((r)=>{
  //             navigate("/")
  //           })
  //         })
  //       }
  //     })
  // }


  // async function onregister(e) {
  //   e.preventDefault();
  
  //   try {
  //     const userCredential = await createUserWithEmailAndPassword(auth, email, password);
  //     const user = userCredential.user;
  
  //     if (user) {
  //       await updateProfile(user, {
  //         displayName: `${firstname} ${lastname}`,
  //         photoURL: "images/faceuser.png"
  //       });
  
  //       // Save user data to Firestore
  //       await db.collection('users').doc(user.uid).set({
  //         uid: user.uid,
  //         displayName: user.displayName,
  //         email: user.email,
  //         photoURL: "images/faceuser.png",
  //         birthday,
  //         gender,
  //         bio: ""
  //       });
  
  //       navigate("/");
  //     }
  //   } catch (error) {
  //     alert("Error registering user:" + error);
  //   }
  // }

  async function onregister(e) 
  {
    e.preventDefault(); 
    try 
    {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
  
      if (user) 
      {
        await updateProfile(user, {
          displayName: `${firstname} ${lastname}`,
          photoURL: "images/faceuser.png"
        });
  
        // Save user data to Firestore
        const userRef = doc(db, 'users', user.uid);
        await setDoc(userRef, 
        {
          uid: user.uid,
          displayName: user.displayName,
          email: user.email,
          photoURL: "images/faceuser.png",
          birthday,
          gender,
          bio: ""
        });
  
        navigate("/");
      }
    } 
    catch (error) 
    {
      alert("Error:" +error);
    }
  }
  

  return (
    <div className='register'>
        <img src='images/pngimg.com - facebook_logos_PNG19749.png' className='register_logo'/>
        <div className='register_container'>
            <h3>Sign Up</h3>
            <p>It's quick and easy</p>
            <div className='hr3'/>
            <form>
                <div className='row'>
                    <input type='name'placeholder='First Mame'onChange={(e)=>setfirstname(e.target.value)} className='register_name' required/>
                    <input type='name'placeholder='Last Mame'onChange={(e)=>setlastname(e.target.value)} className='register_name' required/>
                </div>
                <center>
                  <input type='email'placeholder='Email Address'onChange={(e)=>setemail(e.target.value)} required/>
                </center>
                <center>
                  <input type='Password'placeholder='Password'onChange={(e)=>setpassword(e.target.value)} required/>
                </center>
                <h5 className='register_date'>Date of Birth</h5>

                <div className='row'>
                    <select className='register_date2' onChange={(e)=>setbirthday([...birthday , e.target.value])} required>
                      <option value="Day">Day</option>
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                      <option>6</option>
                      <option>7</option>
                      <option>8</option>
                      <option>9</option>
                      <option>10</option>
                      <option>11</option>
                      <option>12</option>
                      <option>13</option>
                      <option>14</option>
                      <option>15</option>
                      <option>16</option>
                      <option>17</option>
                      <option>18</option>
                      <option>19</option>
                      <option>20</option>
                      <option>21</option>
                      <option>22</option>
                      <option>23</option>
                      <option>24</option>
                      <option>25</option>
                      <option>26</option>
                      <option>27</option>
                      <option>28</option>
                      <option>29</option>
                      <option>30</option>
                      <option>31</option>
                    </select>

                    <select className='register_date3' onChange={(e)=>setbirthday([...birthday , e.target.value])} required>
                      <option value="Day">Month</option>
                      <option>Jan</option>
                      <option>Feb</option>
                      <option>Mar</option>
                      <option>Apr</option>
                      <option>May</option>
                      <option>Jun</option>
                      <option>Jul</option>
                      <option>Aug</option>
                      <option>Sep</option>
                      <option>Oct</option>
                      <option>Nov</option>
                      <option>Dec</option>
                    </select>

                    <select className='register_date3' onChange={(e)=>setbirthday([...birthday , e.target.value])} required>
                      <option value="Day">Month</option>
                      <option>2024</option>
                      <option>2023</option>
                      <option>2022</option>
                      <option>2021</option>
                      <option>2020</option>
                      <option>2019</option>
                      <option>2018</option>
                      <option>2017</option>
                      <option>2016</option>
                      <option>2015</option>
                      <option>2014</option>
                      <option>2013</option>
                      <option>2012</option>
                      <option>2011</option>
                      <option>2010</option>
                      <option>2009</option>
                      <option>2008</option>
                      <option>2007</option>
                      <option>2006</option>
                      <option>2005</option>
                      <option>2004</option>
                      <option>2003</option>
                      <option>2002</option>
                      <option>2001</option>
                      <option>2000</option>
                      <option>1999</option>
                      <option>1998</option>
                      <option>1997</option>
                      <option>1996</option>
                      <option>1995</option>
                      <option>1994</option>
                      <option>1993</option>
                      <option>1992</option>
                      <option>1991</option>
                      <option>1990</option>
                      <option>1989</option>
                      <option>1988</option>
                      <option>1987</option>
                      <option>1986</option>
                      <option>1985</option>
                      <option>1984</option>
                      <option>1983</option>
                      <option>1982</option>
                      <option>1981</option>
                      <option>1980</option>
                    </select>
                </div>

                <h5 className='register_gender'>Gender</h5>

                <div className='register_radiocontainer'>
                  <div className='wrapper'>
                    <label>Female</label>
                      <input type='radio' required name="gender" onChange={(e)=>setgender(e.target.value)} value="Female"/>
                  </div>
                  <div className='wrapper'>
                    <label>Male</label>
                      <input type='radio' required name="gender" onChange={(e)=>setgender(e.target.value)} value="Male"/>
                  </div>
                  <div className='wrapper'>
                    <label>Others</label>
                      <input type='radio' required name="gender" onChange={(e)=>setgender(e.target.value)} value="Others" />
                  </div>
                </div>
                <p className='register_policy'>
                    By clicking Sign Up , you agree to our{" "}
                    <span>Terms, Data Policy</span> and <span>Cookie Policy</span>. You may recieve SMS notification from us and can opt out at any time.
                </p>

                <center>
                  <button onClick={onregister} type='submit' className='register_register'>
                    Sign Up
                  </button>
                </center>

                <center>
                  <Link to="/login">
                    <p className='register_login'>Already have an account ?</p>
                  </Link>
                </center>
            </form>
        </div>
    </div>
  )
}

export default Register
