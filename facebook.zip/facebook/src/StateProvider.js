import React, { createContext, useContext, useReducer } from 'react';

// Create a Context
const StateContext = createContext();

// Create a Provider Component
export const StateProvider = ({ reducer, initialState, children }) => (
  <StateContext.Provider value={useReducer(reducer, initialState)}>
    {children}
  </StateContext.Provider>
);

// Custom hook to use the State Context
export const useStateValue = () => useContext(StateContext);
