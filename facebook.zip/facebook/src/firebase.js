import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore'

const firebaseConfig = {
    apiKey:"AIzaSyADChs8ohaekwJvng015hNC4TSWrP1p-qo",
    authDomain: "facebook-f3bd1.firebaseapp.com",
    projectId: "facebook-f3bd1",
    storageBucket: "facebook-f3bd1.appspot.com",
    messagingSenderId: "87140365447",
    appId: "1:87140365447:web:d43d81149e23df88dfb422",
    measurementId: "G-FHXFR6GW8X"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { auth , db };
