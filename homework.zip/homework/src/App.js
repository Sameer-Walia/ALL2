import './App.css';
import Comp1 from './Comp1';
import Comp2 from './Comp2';
import Arithmetic from './Arithmetic';
import EventHandling from './EventHandling';
import TerniaryOperator from './TerniaryOperator';
import SimpleInterest from './SimpleInterest';
import TerniaryOperator1 from './TerniaryOperator1';
import TerniaryOperator2 from './TerniaryOperator2';
import Signup from './SignUp';
import UseEffect from './UseEffect';
import UseEffect1 from './UseEffect1';
import RadioButton from './RadioButton';
import SelectBox from './SelectBox';
import CheckBox from './CheckBox';
import CheckBox1 from './CheckBox1';

function App() {

  
  return (
    <div className="App">
      {/* <Comp1 stuname="Rajesh" age="21"></Comp1>  
      <h2>welcome to react</h2>   */}
      <Comp2  studata={{ name: "Sameer" , Age : 22 , Gender : "Male"}}/>
      {/* <Comp1/> */}

      {/* <EventHandling/> */}
      {/* <Arithmetic/> */}
      {/* <TerniaryOperator/> */}
      {/* <TerniaryOperator1/> */}
      {/* <TerniaryOperator2/> */}
      {/* <SimpleInterest/> */} 
      {/* <Signup/> */}
      {/* <UseEffect/> */}
      {/* <UseEffect1/> */}
      {/* <RadioButton/> */}
      {/* <SelectBox/> */}
      {/* <CheckBox/> */}
      {/* <CheckBox1/> */}

      

    </div>
  );
}

export default App;
