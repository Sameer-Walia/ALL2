import { useState } from 'react';
function Arithmetic()
{
    const[fno , setfno]=useState();
    const[sno , setsno]=useState();
    const[add , setadd]=useState();
    const[mul , setmul]=useState();
    const[div , setdiv]=useState();
    const[sub , setsub]=useState();

    function caladd()
    {
      setadd(Number(fno) + parseInt(sno))
    }
    function calmul()
    {
      setmul(Number(fno) * parseInt(sno))
    }
    function caldiv()
    {
      setdiv(Number(fno) / parseInt(sno))
    }
    function calsub()
    {
      setsub(Number(fno) - parseInt(sno))
    }

    return(
        <>
            <h2>Enter Numbers</h2>
            <input type="text" name="fno" placeholder="Enter First Number" onChange={(e)=>setfno(e.target.value)}/><br/><br/>
            <input type="text" name="sno" placeholder="Enter Second Number" onChange={(e)=>setsno(e.target.value)}/><br/><br/>
            <button onClick={caladd}>Addition</button>&nbsp;&nbsp;&nbsp;
            <button onClick={calmul}>Mutliply</button>&nbsp;&nbsp;&nbsp;
            <button onClick={caldiv}>Division</button>&nbsp;&nbsp;&nbsp;
            <button onClick={calsub}>Subtraction</button><br/><br/>
            Addition       is {add} <br></br>
            Multiplication is {mul} <br></br>
            Division       is {div} <br></br>
            Subtraction    is {sub} 
        </>
    )
}
export default Arithmetic;