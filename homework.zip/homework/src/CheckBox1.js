import { useState , useEffect} from "react";

function CheckBox1()
{
    const[item1 , setitem1] = useState(false)
    const[item2 , setitem2] = useState(false)
    const[item3 , setitem3] = useState(false)
    const[item4 , setitem4] = useState(false)
    const[item5 , setitem5] = useState(false)
    const[flag , setflag] = useState(false)
    const[sel , setsel] = useState()
    const[d , setd] = useState()
    const[dis , setdis] = useState(null)
    const[r , setr] = useState()
    const[gst , setgst] = useState()
    const[total , settotal] = useState()

    useEffect(()=>
    {
        setsel((item1?250:0)+(item2?80:0)+(item3?50:0)+(item4?100:0)+(item5?150:0))
    }, [item1 , item2 , item3 ,item4 , item5])

    function caltotal()
    {
        setflag(true)
        if(sel>=500)
        {
            setd("U will get 10% discount")
            setdis((Number(sel))/10)
        }
        else if(sel>=350)
        {
            setd("U will get 7.5% discount")
            setdis((Number(sel))/7.5)
        }
        else if(sel>=200)
        {
            setd("U will get 5% discount")
            setdis((Number(sel))/5)
        }
        else
        {
            setd("No discount")
            setdis(0)
        }
    }

    useEffect(()=>
    {
        setr(Number(sel)-Number(dis))
    }, [dis])

    useEffect(()=>
    {
        setgst((Number(r)*5)/100)
    }, [r])

    useEffect(()=>
    {
        settotal(Number(r)+Number(gst))
    }, [gst])


    return(
        <>
            <br/><br/><input type="checkbox" name="cb1" onChange={(e)=>setitem1(e.target.checked)}></input>Pizza - Rs-250/- <br/>
            <input type="checkbox" name="cb2" onChange={(e)=>setitem2(e.target.checked)}></input>Burger - Rs-80/- <br/>
            <input type="checkbox" name="cb3" onChange={(e)=>setitem3(e.target.checked)}></input>Cold Drink - Rs-50/- <br/>
            <input type="checkbox" name="cb4" onChange={(e)=>setitem4(e.target.checked)}></input>Sandwhich - Rs-100/- <br/>
            <input type="checkbox" name="cb5" onChange={(e)=>setitem5(e.target.checked)}></input>Pasta - Rs-150/- <br/>

            <button name="btn" onClick={caltotal}>Calculate total</button><br/><br/>

            {
                flag===true?
                <>
                    Amount : {sel}<br/><br/>
                    Discount: {d}<br/><br/>
                    Discount: {dis}<br/><br/>
                    Remaining Amount: {r}<br/><br/>
                    Gst: {gst}<br/><br/>
                    Total Amount: {total}

                </>:null
            }
        </>
    )
}
export default CheckBox1;