import Comp3 from "./Comp3";

// var Comp1=()=>
function Comp1(mydata)
{
    return(
        <>
            <h3>Component 1 is Called</h3>
            <h2>Welcome {mydata.stuname}</h2>
            <h3>Age is {mydata.age}</h3>
            <Comp3/>
        </>
    )
}
export default Comp1;