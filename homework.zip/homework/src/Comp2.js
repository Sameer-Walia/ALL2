import Comp3 from "./Comp3";

// var Comp2=()=>
function Comp2(mydata)
{
    return(
        <>
            <h2>Compnent 2 is Called</h2>
            <h1>Welcome {mydata.studata.name}</h1>
            <h1>Age is {mydata.studata.Age}</h1>
            <h1>Gender is {mydata.studata.Gender}</h1>
            <Comp3></Comp3>
        </>
    )
}
export default Comp2;