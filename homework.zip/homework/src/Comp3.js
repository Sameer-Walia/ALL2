// var Comp3=()=>
    function Comp3()
{
    return(
        <>
            <h1>Compnent 3 is Called</h1>
        </>
    )
}
export default Comp3;