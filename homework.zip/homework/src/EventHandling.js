function EventHandling()
{
    function showmsg(msg)
    {
        alert(msg);
    }
    
    return(
        <>
            <button name="btn1" onClick={()=>showmsg("Welcome To React")}>Click Here</button>&nbsp;&nbsp;
            <button name="btn2" onClick={()=>showmsg("Welcome To Coding World")}>Click Here</button>&nbsp;&nbsp;
            <button name="btn3" onClick={()=>showmsg("Welcome To Mern Stack")}>Click Here</button>&nbsp;
        </>
    )
}
export default EventHandling;