import { useEffect, useState } from "react";

function RadioButton()
{
    const[ name , setname] = useState()
    const[ sal , setsal] = useState()
    const[ gen , setgen] = useState()
    const[ w , setw] = useState()
    const[ b , setb] = useState()
    const[ bonus , setbonus] = useState(null)
    const[ tsalary , settsalary] = useState()
    const[ flag , setflag] = useState(false)

    function cal()
    {
        setflag(true)
        if(gen==="Male" && w==="Marketing")
        {
            setb("10% of salary")
            setbonus((Number(sal)*10)/100)
        }
        else if(gen==="Male" && w==="Management")
        {
            setb("8% of salary")
            setbonus((Number(sal)*8)/100)
        }
        if(gen==="Female" && w==="Marketing")
        {
            setb("12% of salary")
            setbonus((Number(sal)*12)/100)
        }
        if(gen==="Female" && w==="Management")
        {
            setb("6% of salary")
            setbonus((Number(sal)*6)/100)
        }
    }
    useEffect(()=>
    {
        if(bonus!==null)
        {
            settsalary(Number(bonus)+Number(sal))       
        }
    },[bonus])


    return(
        <>
            <h1>Enter Information</h1>
            <input type="name" placeholder="Enter Name" name="nm" onChange={(e)=>setname(e.target.value)}></input><br/><br/>
            <input type="name" placeholder="Enter Salary" name="salary" onChange={(e)=>setsal(e.target.value)}></input><br/><br/>
            Gender :-<label><input type="radio" name="gender" value="Male" onChange={(e)=>setgen(e.target.value)}></input>Male</label>
            <label><input type="radio" name="gender" value="Female" onChange={(e)=>setgen(e.target.value)}></input>Female</label><br/><br/>
            Work :-<label><input type="radio" name="work" value="Marketing" onChange={(e)=>setw(e.target.value)}></input>Marketing</label>
            <label><input type="radio" name="work" value="Management" onChange={(e)=>setw(e.target.value)}></input>Management</label><br/><br/>
            <button name="btn" onClick={cal}>Calculate</button><br/><br/>
            {
                flag===true?
                <>
                    Name : {name}<br/><br/>
                    Salary : {sal}<br/><br/>
                    Gender : {gen}<br/><br/>
                    Work  : {w}<br/><br/>
                    Bonus : {b}<br/><br/>
                    Bonus : {bonus}<br/><br/>
                    Total Salary: {tsalary}
                </>:null
            }

        </>
    )
}
export default RadioButton;