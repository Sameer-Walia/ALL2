import { useState } from "react";

function SelectBox()
{
    const[coun , setcoun] = useState()
    const[msg , setmes] = useState()

    function showmsg()
    {
        if(coun==="ind")
        {
            setmes("Capital is Delhi")
        }
        else if(coun==="100")
        {
            setmes("Capital is New York")
        }
        else if(coun==="Canada")
        {
            setmes("Capital is Otava")
        }
    }

    return(
        <>
            <select name="co" onChange={(e)=>setcoun(e.target.value)}>
                <option value="">Choose Country</option>
                <option value="ind">India</option>
                <option value="100">USA</option>
                <option>Canada</option>
            </select><br/><br/>
            <button name="btn" onClick={showmsg}>Calculate</button><br/><br/>
            {msg}
        </>
    )
}
export default SelectBox;