import { useState } from "react";

function Signup()
{
    const[name , setname] = useState();
    const[phone , setphone] = useState();
    const[email , setemail] = useState();
    const[pass , setpass] = useState();
    const[gen , setgen] = useState();
    const[co , setco] = useState();
    const[hob1 , sethob1] = useState(false);
    const[hob2 , sethob2] = useState(false);
    const[hob3 , sethob3] = useState(false);
    const[terms , setterms] = useState(false);
    const[flag ,setflag] = useState(false)

    function onsignup()
    {
        setflag(true)
        console.log(name,phone,email,pass,gen,co,hob1,hob2,hob3,terms)
    }

    return(
        <>
            <h2>Register</h2>
            <input type="text" name="pname" placeholder="name" onChange={(e)=>setname(e.target.value)}></input><br/><br/>
            <input type="tel" name="phone" placeholder="Phone" onChange={(e)=>setphone(e.target.value)}></input><br/><br/>
            <input type="email" name="email" placeholder="email" onChange={(e)=>setemail(e.target.value)}></input><br/><br/>
            <input type="password" placeholder="enter password" onChange={(e)=>setpass(e.target.value)}></input><br/><br/>
            
            <label><input type="radio" name="gender" value="male" onChange={(e)=>setgen(e.target.value)}></input>Male</label>
            <label><input type="radio" name="gender" value="female" onChange={(e)=>setgen(e.target.value)}></input>Female</label><br/><br/>

            <select name="co" onChange={(e)=>setco(e.target.value)}>
                <option value="">Choose Country</option>
                <option value="ind">India</option>
                <option value="100">USA</option>
                <option>Canada</option>
            </select><br/><br/>

            Hobbies:-
            <input type="checkbox" name="cb1" onChange={(e)=>sethob1(e.target.checked)}></input>Singing
            <input type="checkbox" name="cb2" onChange={(e)=>sethob2(e.target.checked)}></input>Dancing
            <input type="checkbox" name="cb3" onChange={(e)=>sethob3(e.target.checked)}></input>Reading<br/><br/>

            <input type="checkbox" name="cb4" onChange={(e)=>setterms(e.target.checked)}></input>I Accept Terms and Condition<br/><br/>


            <button name="btn" onClick={onsignup}>Register</button><br/><br/>

            {
                flag===true?
                <>
                    Name is {name}<br/><br/>
                    Phone Number is {phone}<br/><br/>
                    Email Id is {email}<br/><br/>
                    Password is {pass}<br/><br/>
                    Gender  is {gen}<br/><br/>
                    Country is {co}<br/><br/>
                    Hobbies :- {hob1} {hob2} {hob3}<br/><br/>
                    Terms And Condition :-{terms}<br/><br/>
                </>:null
            }


        </> 
    )
}
export default Signup;