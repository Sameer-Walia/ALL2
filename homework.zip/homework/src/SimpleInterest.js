import { useState } from "react";

function SimpleInterest()
{
    const[pa , setpa]=useState();
    const[r , setr]=useState();
    const[t , sett]=useState();
    const[sum , setsum]=useState();

    function cal()
    {
        setsum((Number(pa)*Number(r)*Number(t))/100)
    }

    return(
        <>
            <h1>Simple Interest</h1>
            <input type="number" placeholder="Principal Amount" onChange={(e)=>setpa(e.target.value)}></input><br/><br/>
            <input type="number" placeholder="Enter rate" onChange={(e)=>setr(e.target.value)}></input><br/><br/>
            <input type="number" placeholder="Enter Time" onChange={(e)=>sett(e.target.value)}></input><br/><br/>
            <button onClick={cal}>Simple Interest</button><br/><br/>
            SimpleInterest is {sum}
        </>
    )
}
export default SimpleInterest;