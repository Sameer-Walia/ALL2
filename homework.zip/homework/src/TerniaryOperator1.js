import { useState } from "react";

function TerniaryOperator1()
{
    const[showsignup , setshowsignup] = useState(false);
    const[showlogin , setshowlogin] = useState(true);

    function signupbutton()
    {
        setshowlogin(false);
        setshowsignup(true)
    }
    function loginbutton()
    {
        setshowlogin(true);
        setshowsignup(false)
    }

    return(
        <>
            <button onClick={signupbutton}>SignUp Form</button>&nbsp;&nbsp;
            <button onClick={loginbutton}>Login Form</button>
            {
                showlogin===true?
                
                    <form>
                        <h1>Login Form</h1>
                        <input type="text" placeholder="enter name"></input><br/><br/>
                        <input type="email" placeholder="enter email"></input><br/><br/>
                        <input type="submit" value="login"></input>
                    </form>:null                
            }
            {
                showsignup===true?

                    <form>
                        <h1>SignUp Form</h1>
                        <input type="text" placeholder="enter name"></input><br/><br/>
                        <input type="email" placeholder="enter email"></input><br/><br/>
                        <input type="password" placeholder="enter password"></input><br/><br/>
                        <input type="submit" value="SignUp"></input>
                    </form>:null               
            }
        </>
    )
}
export default TerniaryOperator1;