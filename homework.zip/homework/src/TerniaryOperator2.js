import { useState } from "react";

function TerniaryOperator2()
{
    const[showsignup , setshowsignup] = useState(false);
    const[showlogin , setshowlogin] = useState(true);

    function signupbutton()
    {
        setshowlogin(false);
        setshowsignup(true)
    }
    function loginbutton()
    {
        setshowlogin(true);
        setshowsignup(false)
    }

    if(showlogin===true)
    {
        return(
            <>
                <button onClick={signupbutton}>SignUp Form</button>
                {                  
                    <form>
                        <h1>Login Form</h1>
                        <input type="text" placeholder="enter name"></input><br/><br/>
                        <input type="email" placeholder="enter email"></input><br/><br/>
                        <input type="submit" value="login"></input>
                    </form>   
                }             
            </>
        )
    }
    else if(showsignup===true)
    {
        return(
            <>
                <button onClick={loginbutton}>Login Form</button>                  
                <form>
                    <h1>SignUp Form</h1>
                    <input type="text" placeholder="enter name"></input><br/><br/>
                    <input type="email" placeholder="enter email"></input><br/><br/>
                    <input type="password" placeholder="enter password"></input><br/><br/>
                    <input type="submit" value="SignUp"></input>
                </form>                               
            </>
        )
    }
}
export default TerniaryOperator2;