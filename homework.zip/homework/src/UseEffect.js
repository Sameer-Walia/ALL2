import { useEffect, useState } from "react";
function UseEffect()
{
    const[name , setname] = useState()
    const[age , setage] = useState()
    const[sal, setsal] = useState()
    const[bonus , setbonus] = useState(null)
    const[tamt , settamt] = useState()
    const[flag , setflag] = useState(false)

    function calsi()
    {
        setflag(true)
        if(age>=50)
        {
            setbonus((15*sal)/100)
        }
        else if(age>=35)
        {
            setbonus((9.6*sal)/100)
        }
        else if(age>=20)
        {
            setbonus((6.7*sal)/100)
        }
        else
        {
            setbonus(0)
        }      
    }

    useEffect( ()=>
    {
        if(bonus!==null)
        {
            settamt(Number(bonus)+Number(sal))
        }
    },[bonus])

    
    return(
        <>
            <br/><br/><input type="text" name="name" placeholder="Name..." onChange={(e)=>setname(e.target.value)}></input><br/><br/>
            <input type="text" name="age" placeholder="Age..." onChange={(e)=>setage(e.target.value)}></input><br/><br/>
            <input type="text" name="salary" placeholder="Salary..." onChange={(e)=>setsal(e.target.value)}></input><br/><br/>
            <button onClick={calsi}>Total Salary</button><br/><br/>
            {
                flag===true?
                <>
                    Welcome      :- {name}<br/><br/>
                    Your Age     :- {age}<br/><br/>
                    Your Salary  :- {sal}<br/><br/>
                    Your Bonus   :- {bonus}<br/><br/>
                    Total Salary :- {tamt}<br/><br/>
                </>:null
            }
            
        </>
    )
}
export default UseEffect;