import { useEffect, useState } from "react";
function UseEffect1()
{
    const[p , setp] = useState()
    const[time , settime] = useState()
    const[rate , setrate] = useState()
    const[si , setsi] = useState(null)
    const[tamt , settamt] = useState()
    const[flag , setflag] = useState(false)

    function calsi()
    {
        setflag(true)
        if(time>=3 && time<6)
        {
            setsi((Number(p)*Number(time)*8)/100)
            setrate("8")
        }
        else if(time>=6 && time<9)
        {
            setsi((Number(p)*Number(time)*7.4)/100)
            setrate("7.4")
        }
        else if(time>=9)
        {
            setsi((Number(p)*Number(time)*6.4)/100)
            setrate("6.4")
        }
        else
        {
            setsi((Number(p)*Number(time)*9)/100)
            setrate("9")
        }
    }

    useEffect(()=>
    {
        if(si!==null)
        {
            settamt(Number(si)+Number(p))
        }
    },[si])
    
    return(
        <>
            <br/><br/><input type="text" name="principal" placeholder="Principal..." onChange={(e)=>setp(e.target.value)}></input><br/><br/>
            <input type="text" name="time" placeholder="Time...." onChange={(e)=>settime(e.target.value)}></input><br/><br/>
            <button onClick={calsi}>Total Amount</button><br/><br/>
            {
                flag===true?
                <>
                    Principal Amount : {p}<br/><br/>
                    Time : {time}<br/><br/>
                    Rate : {rate}<br/><br/>
                    Simple Interest : {si}<br/><br/>
                    Total Amount : {tamt}<br/><br/>
                </>:null
            }           
        </>
    )
}
export default UseEffect1;