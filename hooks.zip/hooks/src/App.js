import logo from './logo.svg';
import './App.css';
import UseImperativeHandle from './Hooks/UseImperativeHandle';
import { useRef } from 'react';
import UseId from './Hooks/UseId';

function App()
{
  const fancyinputref = useRef(null)

  return (
    <div className="App">
      <UseImperativeHandle ref={fancyinputref} />
      <button className='btn-primary' onClick={() => fancyinputref.current.focus()}>Focus</button>
      <button className='btn-gray' onClick={() => fancyinputref.current.clear()}>Clear</button>
      
      <br />
      <br />

      <UseId />
    </div>
  );
}

export default App;
