import React, { useId, useState } from 'react'

function UseId()
{
    const id = useId()
    const id2 = useId()
    return (
        <div>
            <h1>Use Id Hook</h1>
            <input type='checkbox' id={id} />
            <label htmlFor={id}>Accept Terms</label><br />
            <input type='checkbox' id={id2} />
            <label htmlFor={id2}>Accept Terms</label>
        </div>
    )
}

export default UseId
