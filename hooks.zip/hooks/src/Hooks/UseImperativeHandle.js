import React, { useImperativeHandle, useRef, useState } from 'react'

function UseImperativeHandle({ ref })
{

    const [data, setData] = useState()
    const inputref = useRef(null)

    useImperativeHandle(ref, () =>
    ({
        focus: () =>
        {
            inputref.current.focus()
        },
        clear: () =>
        {
            inputref.current.value = ""
        }
    }))

    return (
        <>
            <h1>Use Imperative Handle HOOK</h1>
            <div className="sam">
                <input type="text" ref={inputref} placeholder='Enter Something' value={data} onChange={(e) => setData(e.target.value)} />
                <p><b>{data}</b></p>
            </div>
        </>
    )
}

export default UseImperativeHandle
